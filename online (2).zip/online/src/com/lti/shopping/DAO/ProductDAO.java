package com.lti.shopping.DAO;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.shopping.model.Product;

@Repository
public interface ProductDAO {

	public Product get(Integer product_id);
	public List<Product> listProducts();
	void add(Product product);
	void updProduct(Product product);
	void delProduct(int product_id);


}
