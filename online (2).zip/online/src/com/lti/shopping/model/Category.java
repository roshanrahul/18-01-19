//
//  package com.lti.shopping.model;
//  
//  import java.io.Serializable;
//import java.util.List;
//
//import javax.persistence.CascadeType;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.OneToMany;
//import javax.persistence.Table;
//  
//  
//  
//  @Entity 
//  @Table(name = "Category")
//  public class Category implements Serializable {
//	  private static final long serialVersionUID = 1L;
//		
//	  @OneToMany(cascade = CascadeType.ALL,mappedBy="category")  
//	/* @JoinColumn(name="product_id") */
//	List<Product> pt;
//	 
//	 
//	  
//	  
//	 // private List<Product> plist;
//	  
//	  
//  
//  @Id
//  @GeneratedValue(strategy = GenerationType.AUTO) 
//  private int catid;
//  
// 
//  private String category_name;
//  
//  public int getCatid() { return catid; }
//  
//  public void setCatid(int catid) { this.catid = catid; }
//  
//  public String getCategory_name() { return category_name; }
//  
//  public void setCategory_name(String category_name) { this.category_name =
//  category_name; }
//
//public Category(int catid, List<Product> pt,  String category_name) {
//	super();
//	this.catid = catid;
//	this.pt = pt;
//
//	this.category_name = category_name;
//}
//
//public Category() {
//	super();
//}
//
//@Override
//public String toString() {
//	return "Category [catid=" + catid + ", pt=" + pt +  ", category_name=" + category_name + "]";
//}
//  
//  
//  
//  
//  
//  
//  
//  
//  }
// 