package com.lti.shopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.shopping.DAO.ProductDAO;
import com.lti.shopping.model.Product;


@Service
@Transactional
public class ProductServiceImpl implements ProductService {

	
	 @Autowired
	private ProductDAO productDAO;
	


	public void setProductDAO(ProductDAO productDAO) {
		this.productDAO = productDAO;
	}

     @Override
	public Product get(Integer product_id) {
		 
		return productDAO.get(product_id);
	}

	

	@Override
	public void add(Product product) {
		System.out.println("in service");
		this.productDAO.add(product);
		
	}
	@Transactional
	@Override
	public void update(Product product) {
		System.out.println("in updservice");
		this.productDAO.updProduct(product);
		System.out.println("after updservice");
	}
	
	@Override
	public void delete(int product_id) {
		this.productDAO.delProduct(product_id);;
		
	}

	@Override
	@Transactional
	public List<Product> listProducts() {
		return productDAO.listProducts();
	}

	 

}
