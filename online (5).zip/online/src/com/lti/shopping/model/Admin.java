package com.lti.shopping.model;

public class Admin {

}
